## *Banking-App*

--> Designed a banking transaction App using Java to simulate
the common functions of using a bank account.

--> Used Android Studio and XML to create a GUI that supports actions
such as an account, transfer, list all accounts, etc.

--> Implemented object-oriented programming practices and used SQL
for databases.

By using this app,User can see their bank details and can transfer money to other user's. Then, User can able see their transactions history.

*Working Video Link:* https://www.youtube.com/watch?v=2sinSmI3qMg

![Yellow and White Geometric  Business Facebook Cover](https://user-images.githubusercontent.com/63442418/194692684-f19e2d04-5596-4555-b0c1-169ce3d0ec5c.png)


![Yellow and White Geometric  Business Facebook Cover (1)](https://user-images.githubusercontent.com/63442418/194692699-773fd406-6049-4293-93a3-889ea703f4e3.png)
